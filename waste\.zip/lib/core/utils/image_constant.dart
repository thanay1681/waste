class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Pickup details images
  static String imgFrame4 = '$imagePath/img_frame_4.png';

  // Details confirmation images
  static String imgFrame4256x360 = '$imagePath/img_frame_4_256x360.png';

  // Pickup Confirmed images
  static String imgUnsplashOij61cg6s6s =
      '$imagePath/img_unsplash_oij61cg6s6s.png';

  // Grievence images
  static String imgUnsplashVykbibI2bc =
      '$imagePath/img_unsplash_vykbib_i2bc.png';

  static String imgUnsplashQsuer9xyoy =
      '$imagePath/img_unsplash_qsuer9xyoy.png';

  // worker home page images
  static String imgImage140x36 = '$imagePath/img_image_1_40x36.png';

  static String imgImage240x40 = '$imagePath/img_image_2_40x40.png';

  // Status images
  static String imgFrame41 = '$imagePath/img_frame_4_1.png';

  // Unloading of Trash images
  static String imgImage16515x331 = '$imagePath/img_image_16_515x331.png';

  // Common images
  static String imgStatusBar = '$imagePath/img_status_bar.svg';

  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgFluenteye20filled = '$imagePath/img_fluenteye20filled.svg';

  static String imgFacebookIc = '$imagePath/img_facebook_ic.svg';

  static String imgGoogleIc = '$imagePath/img_google_ic.svg';

  static String imgCibApple = '$imagePath/img_cib_apple.svg';

  static String imgCheckmark = '$imagePath/img_checkmark.svg';

  static String imgUnsplashAi4rjMw4i = '$imagePath/img_unsplash_ai4rj_mw4i.png';

  static String imgEllipse1 = '$imagePath/img_ellipse_1.png';

  static String imgSubtract = '$imagePath/img_subtract.svg';

  static String imgScreenshot20231013 =
      '$imagePath/img_screenshot_2023_10_13.png';

  static String imgImage1 = '$imagePath/img_image_1.png';

  static String imgRectangle1 = '$imagePath/img_rectangle_1.png';

  static String imgImage2 = '$imagePath/img_image_2.png';

  static String imgEllipse4 = '$imagePath/img_ellipse_4.png';

  static String imgEllipse437x40 = '$imagePath/img_ellipse_4_37x40.png';

  static String imgEllipse436x40 = '$imagePath/img_ellipse_4_36x40.png';

  static String imgImage16 = '$imagePath/img_image_16.png';

  static String img1485477216CloudText78566 =
      '$imagePath/img_1485477216_cloud_text_78566.png';

  static String imgImage12 = '$imagePath/img_image_12.png';

  static String imgImage13 = '$imagePath/img_image_13.png';

  static String imgImage14 = '$imagePath/img_image_14.png';

  static String imgImage15 = '$imagePath/img_image_15.png';

  static String imgUser = '$imagePath/img_user.png';

  static String imgImage19 = '$imagePath/img_image_19.png';

  static String imgArrow1 = '$imagePath/img_arrow_1.svg';

  static String imgImage5 = '$imagePath/img_image_5.png';

  static String imgImage1542x103 = '$imagePath/img_image_15_42x103.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
