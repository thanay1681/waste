import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class RegisteredScreen extends StatelessWidget {
  const RegisteredScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: 375.h,
                child: Column(children: [
                  SizedBox(height: 254.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: _buildRegisteredSection(context)))
                ]))));
  }

  /// Section Widget
  Widget _buildRegisteredSection(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 22.h, right: 22.h, bottom: 297.v),
        child: Column(children: [
          CustomImageView(
              imagePath: ImageConstant.imgCheckmark,
              height: 100.adaptSize,
              width: 100.adaptSize),
          SizedBox(height: 32.v),
          Text("Successfully Registered",
              style: theme.textTheme.headlineMedium),
          SizedBox(height: 40.v),
          CustomElevatedButton(
              text: "Back to Login",
              onPressed: () {
                onTapBackToLogin(context);
              })
        ]));
  }

  /// Navigates to the loginOneScreen when the action is triggered.
  onTapBackToLogin(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginOneScreen);
  }
}
