import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class WorkerHomePage extends StatelessWidget {
  const WorkerHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.lightGreen10001,
            body: Container(
                width: double.maxFinite,
                decoration: AppDecoration.fillLightgreen10001,
                child: Container(
                    padding:
                        EdgeInsets.only(left: 24.h, top: 74.v, right: 24.h),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  margin:
                                      EdgeInsets.symmetric(horizontal: 17.h),
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 50.h, vertical: 5.v),
                                  decoration: AppDecoration.fillGreen.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder20),
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        SizedBox(height: 14.v),
                                        SizedBox(
                                            width: 174.h,
                                            child: RichText(
                                                text: TextSpan(children: [
                                                  TextSpan(
                                                      text: "EcoHarvest\n",
                                                      style: CustomTextStyles
                                                          .headlineLargeRobotoBlack900),
                                                  TextSpan(
                                                      text: "Trash to Treasure",
                                                      style: CustomTextStyles
                                                          .titleLargeRoboto)
                                                ]),
                                                textAlign: TextAlign.center))
                                      ]))),
                          SizedBox(height: 49.v),
                          CustomElevatedButton(
                              height: 53.v,
                              text: "Pending Requests  (x)",
                              margin: EdgeInsets.only(right: 10.h),
                              rightIcon: Container(
                                  margin: EdgeInsets.only(left: 16.h),
                                  child: CustomImageView(
                                      imagePath: ImageConstant.imgArrow1,
                                      height: 3.v,
                                      width: 35.h)),
                              buttonStyle: CustomButtonStyles.fillGreen,
                              buttonTextStyle: CustomTextStyles
                                  .headlineSmallInriaSansOnErrorContainer,
                              onPressed: () {
                                onTapPendingRequestsX(context);
                              }),
                          SizedBox(height: 35.v),
                          CustomElevatedButton(
                              height: 53.v,
                              text: "Completed Requests (x)",
                              margin: EdgeInsets.only(right: 10.h),
                              rightIcon: Container(
                                  margin: EdgeInsets.only(left: 10.h),
                                  child: CustomImageView(
                                      imagePath: ImageConstant.imgArrow1,
                                      height: 3.v,
                                      width: 35.h)),
                              buttonStyle: CustomButtonStyles.fillGreen,
                              buttonTextStyle: CustomTextStyles
                                  .titleLargeInriaSansOnErrorContainer),
                          SizedBox(height: 5.v)
                        ])))));
  }

  /// Navigates to the statusScreen when the action is triggered.
  onTapPendingRequestsX(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.statusScreen);
  }
}
