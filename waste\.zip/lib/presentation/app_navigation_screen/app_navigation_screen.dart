import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:flutter/material.dart';

class AppNavigationScreen extends StatelessWidget {
  const AppNavigationScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFFFFFFFF),
        body: SizedBox(
          width: 375.h,
          child: Column(
            children: [
              _buildAppNavigation(context),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0XFFFFFFFF),
                    ),
                    child: Column(
                      children: [
                        _buildScreenTitle(
                          context,
                          screenTitle: "App home",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.appHomeScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Login One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.loginOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Register",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.registerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "OTP VerificationTwo",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.otpVerificationtwoScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Registered",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.registeredScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Pickup details",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.pickupDetailsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Customer login",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.customerLoginScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Details confirmation",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.detailsConfirmationScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Pickup Confirmed",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.pickupConfirmedScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "OTP Verification",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.otpVerificationScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Reset Password",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.resetPasswordScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Password Changed",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.passwordChangedScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Customer main page - Container",
                          onTapScreenTitle: () => onTapScreenTitle(context,
                              AppRoutes.customerMainPageContainerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "More",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.moreScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Grievence",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.grievenceScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Profile One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.profileOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "profile pic One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.profilePicOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Profile",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.profileScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Frame Two",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.frameTwoScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Status",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.statusScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Employee login",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.employeeLoginScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Login",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.loginScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "Unloading of Trash",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.unloadingOfTrashScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          screenTitle: "profile pic",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.profilePicScreen),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppNavigation(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0XFFFFFFFF),
      ),
      child: Column(
        children: [
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.h),
              child: Text(
                "App Navigation",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF000000),
                  fontSize: 20.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 20.h),
              child: Text(
                "Check your app's UI from the below demo screens of your app.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF888888),
                  fontSize: 16.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 5.v),
          Divider(
            height: 1.v,
            thickness: 1.v,
            color: Color(0XFF000000),
          ),
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildScreenTitle(
    BuildContext context, {
    required String screenTitle,
    Function? onTapScreenTitle,
  }) {
    return GestureDetector(
      onTap: () {
        onTapScreenTitle!.call();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Color(0XFFFFFFFF),
        ),
        child: Column(
          children: [
            SizedBox(height: 10.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.h),
                child: Text(
                  screenTitle,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0XFF000000),
                    fontSize: 20.fSize,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10.v),
            SizedBox(height: 5.v),
            Divider(
              height: 1.v,
              thickness: 1.v,
              color: Color(0XFF888888),
            ),
          ],
        ),
      ),
    );
  }

  /// Common click event
  void onTapScreenTitle(
    BuildContext context,
    String routeName,
  ) {
    Navigator.pushNamed(context, routeName);
  }
}
