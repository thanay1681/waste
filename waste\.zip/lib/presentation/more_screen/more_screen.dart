import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/app_bar/appbar_leading_image.dart';
import 'package:anabathula_s_application3/widgets/app_bar/appbar_subtitle.dart';
import 'package:anabathula_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:anabathula_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class MoreScreen extends StatelessWidget {
  MoreScreen({Key? key}) : super(key: key);

  TextEditingController faqsEditTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.greenA100,
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: Container(
                width: 214.h,
                padding: EdgeInsets.symmetric(horizontal: 11.h, vertical: 17.v),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildProfileSettingsButton(context),
                      SizedBox(height: 32.v),
                      _buildGrievancesButton(context),
                      SizedBox(height: 34.v),
                      _buildFaqsEditText(context),
                      SizedBox(height: 32.v),
                      _buildLogoutButton(context),
                      SizedBox(height: 5.v)
                    ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        height: 57.v,
        leadingWidth: 50.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgUser,
            margin: EdgeInsets.only(left: 10.h, top: 7.v, bottom: 10.v)),
        title: AppbarSubtitle(
            text: "Hello User", margin: EdgeInsets.only(left: 21.h)),
        styleType: Style.bgFill);
  }

  /// Section Widget
  Widget _buildProfileSettingsButton(BuildContext context) {
    return CustomElevatedButton(
        height: 36.v,
        text: "Profile Settings",
        margin: EdgeInsets.only(left: 4.h, right: 26.h),
        buttonStyle: CustomButtonStyles.fillGreen,
        buttonTextStyle: CustomTextStyles.titleLargeInriaSans,
        onPressed: () {
          onTapProfileSettingsButton(context);
        });
  }

  /// Section Widget
  Widget _buildGrievancesButton(BuildContext context) {
    return CustomElevatedButton(
        height: 36.v,
        text: "Grievences",
        margin: EdgeInsets.only(left: 4.h, right: 26.h),
        buttonStyle: CustomButtonStyles.fillGreen,
        buttonTextStyle: CustomTextStyles.titleLargeRegular,
        onPressed: () {
          onTapGrievancesButton(context);
        });
  }

  /// Section Widget
  Widget _buildFaqsEditText(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 3.h, right: 26.h),
        child: CustomTextFormField(
            controller: faqsEditTextController,
            hintText: "FAQ’s",
            textInputAction: TextInputAction.done,
            contentPadding:
                EdgeInsets.symmetric(horizontal: 19.h, vertical: 5.v),
            borderDecoration: TextFormFieldStyleHelper.fillGreen,
            fillColor: appTheme.green800));
  }

  /// Section Widget
  Widget _buildLogoutButton(BuildContext context) {
    return CustomElevatedButton(
        height: 36.v,
        text: "Logout",
        margin: EdgeInsets.only(right: 30.h),
        buttonStyle: CustomButtonStyles.fillGreen,
        buttonTextStyle: CustomTextStyles.titleLargeRegular,
        onPressed: () {
          onTapLogoutButton(context);
        });
  }

  /// Navigates to the profileOneScreen when the action is triggered.
  onTapProfileSettingsButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.profileOneScreen);
  }

  /// Navigates to the grievenceScreen when the action is triggered.
  onTapGrievancesButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.grievenceScreen);
  }

  /// Navigates to the customerLoginScreen when the action is triggered.
  onTapLogoutButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.customerLoginScreen);
  }
}
