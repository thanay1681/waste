import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:anabathula_s_application3/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class UnloadingOfTrashScreen extends StatelessWidget {
  const UnloadingOfTrashScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 10.h,
            vertical: 13.v,
          ),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Trash Drop Location",
                  style: CustomTextStyles.titleLargeRegular23,
                ),
              ),
              SizedBox(height: 2.v),
              CustomImageView(
                imagePath: ImageConstant.imgImage5,
                height: 83.v,
                width: 339.h,
              ),
              SizedBox(height: 4.v),
              CustomImageView(
                imagePath: ImageConstant.imgImage16515x331,
                height: 515.v,
                width: 331.h,
              ),
              SizedBox(height: 14.v),
              CustomElevatedButton(
                height: 53.v,
                text: "Drop Done",
                margin: EdgeInsets.only(
                  left: 15.h,
                  right: 23.h,
                ),
                rightIcon: Container(
                  margin: EdgeInsets.only(left: 30.h),
                  child: CustomImageView(
                    imagePath: ImageConstant.imgArrow1,
                    height: 3.v,
                    width: 35.h,
                  ),
                ),
                buttonStyle: CustomButtonStyles.fillGreen,
                buttonTextStyle:
                    CustomTextStyles.headlineSmallInriaSansOnErrorContainer,
              ),
              SizedBox(height: 24.v),
              CustomIconButton(
                height: 42.v,
                width: 103.h,
                child: CustomImageView(
                  imagePath: ImageConstant.imgImage1542x103,
                ),
              ),
              SizedBox(height: 7.v),
            ],
          ),
        ),
      ),
    );
  }
}
