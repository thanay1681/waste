import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/app_bar/appbar_leading_iconbutton_one.dart';
import 'package:anabathula_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class GrievenceScreen extends StatelessWidget {
  const GrievenceScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.greenA100,
            appBar: _buildAppBar(context),
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.only(left: 41.h, top: 114.v, right: 41.h),
                child: Column(children: [
                  Text("Feel free to call us or Text us",
                      style: theme.textTheme.titleLarge),
                  SizedBox(height: 41.v),
                  Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                          padding: EdgeInsets.only(left: 20.h, right: 6.h),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomImageView(
                                    imagePath:
                                        ImageConstant.imgUnsplashVykbibI2bc,
                                    height: 84.v,
                                    width: 97.h,
                                    radius: BorderRadius.circular(34.h),
                                    margin: EdgeInsets.only(bottom: 8.v)),
                                CustomImageView(
                                    imagePath:
                                        ImageConstant.imgUnsplashQsuer9xyoy,
                                    height: 84.v,
                                    width: 86.h,
                                    radius: BorderRadius.circular(42.h),
                                    margin: EdgeInsets.only(top: 8.v))
                              ]))),
                  SizedBox(height: 93.v),
                  CustomElevatedButton(
                      height: 38.v,
                      width: 193.h,
                      text: "Back to Home",
                      buttonStyle: CustomButtonStyles.fillGreen,
                      buttonTextStyle: theme.textTheme.titleLarge!,
                      onPressed: () {
                        onTapBackToHome(context);
                      }),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: double.maxFinite,
        leading: AppbarLeadingIconbuttonOne(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.fromLTRB(8.h, 7.v, 311.h, 7.v),
            onTap: () {
              onTapArrowLeft(context);
            }));
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }

  /// Navigates to the customerMainPageContainerScreen when the action is triggered.
  onTapBackToHome(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.customerMainPageContainerScreen);
  }
}
