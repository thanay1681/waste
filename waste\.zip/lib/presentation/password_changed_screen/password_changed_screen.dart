import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class PasswordChangedScreen extends StatelessWidget {
  const PasswordChangedScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: 375.h,
                child: Column(children: [
                  SizedBox(height: 214.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: _buildPasswordChangedSection(context)))
                ]))));
  }

  /// Section Widget
  Widget _buildPasswordChangedSection(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 22.h, right: 22.h, bottom: 297.v),
        child: Column(children: [
          CustomImageView(
              imagePath: ImageConstant.imgCheckmark,
              height: 100.adaptSize,
              width: 100.adaptSize),
          SizedBox(height: 32.v),
          Text("Password Changed!", style: theme.textTheme.headlineMedium),
          SizedBox(height: 6.v),
          SizedBox(
              width: 226.h,
              child: Text("Your password has been changed successfully.",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.titleSmall!.copyWith(height: 1.50))),
          SizedBox(height: 28.v),
          CustomElevatedButton(
              text: "Back to Login",
              onPressed: () {
                onTapBackToLogin(context);
              })
        ]));
  }

  /// Navigates to the loginOneScreen when the action is triggered.
  onTapBackToLogin(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginOneScreen);
  }
}
