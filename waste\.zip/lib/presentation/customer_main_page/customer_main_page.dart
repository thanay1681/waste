import '../customer_main_page/widgets/customermainpage_item_widget.dart';
import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class CustomerMainPage extends StatelessWidget {
  const CustomerMainPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: theme.colorScheme.onErrorContainer.withOpacity(1),
            body: Container(
                width: double.maxFinite,
                decoration: AppDecoration.fillOnErrorContainer,
                child: Container(
                    margin: EdgeInsets.only(right: 2.h),
                    padding: EdgeInsets.symmetric(vertical: 24.v),
                    decoration: AppDecoration.fillGreenA,
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildHomeScreen(context),
                          SizedBox(height: 5.v),
                          _buildImageScreen(context),
                          SizedBox(height: 12.v),
                          Padding(
                              padding: EdgeInsets.only(left: 14.h),
                              child: Text("Exchange Goods",
                                  style: CustomTextStyles
                                      .titleMediumRobotoBlack900)),
                          SizedBox(height: 12.v),
                          _buildCustomerMainPage(context),
                          SizedBox(height: 31.v),
                          CustomElevatedButton(
                              height: 65.v,
                              text: "Schedule a pickup",
                              margin: EdgeInsets.only(left: 18.h, right: 33.h),
                              buttonStyle: CustomButtonStyles.fillGreen,
                              buttonTextStyle: CustomTextStyles
                                  .headlineMediumInriaSansBlack900,
                              onPressed: () {
                                onTapScheduleAPickup(context);
                              }),
                          SizedBox(height: 45.v),
                          Align(
                              alignment: Alignment.centerRight,
                              child: Container(
                                  height: 133.v,
                                  width: 147.h,
                                  margin: EdgeInsets.only(right: 15.h),
                                  child: Stack(
                                      alignment: Alignment.topLeft,
                                      children: [
                                        CustomImageView(
                                            imagePath: ImageConstant.imgImage16,
                                            height: 65.adaptSize,
                                            width: 65.adaptSize,
                                            radius: BorderRadius.circular(32.h),
                                            alignment: Alignment.bottomRight),
                                        Align(
                                            alignment: Alignment.topLeft,
                                            child: Container(
                                                width: 49.h,
                                                margin: EdgeInsets.only(
                                                    left: 31.h, top: 26.v),
                                                child: Text(
                                                    "How can I \nhelp you \ntoday!!",
                                                    maxLines: 3,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.center,
                                                    style: CustomTextStyles
                                                        .bodySmallInriaSansBlack900))),
                                        CustomImageView(
                                            imagePath: ImageConstant
                                                .img1485477216CloudText78566,
                                            height: 101.v,
                                            width: 114.h,
                                            alignment: Alignment.topLeft)
                                      ]))),
                          SizedBox(height: 5.v)
                        ])))));
  }

  /// Section Widget
  Widget _buildHomeScreen(BuildContext context) {
    return SizedBox(
        height: 221.v,
        width: 358.h,
        child: Stack(alignment: Alignment.topLeft, children: [
          CustomImageView(
              imagePath: ImageConstant.imgEllipse1,
              height: 46.adaptSize,
              width: 46.adaptSize,
              radius: BorderRadius.circular(23.h),
              alignment: Alignment.topLeft,
              margin: EdgeInsets.only(left: 11.h),
              onTap: () {
                onTapImgCircleImage(context);
              }),
          Align(
              alignment: Alignment.topLeft,
              child: Padding(
                  padding: EdgeInsets.only(left: 66.h, top: 3.v),
                  child: Text("500", style: theme.textTheme.displaySmall))),
          CustomImageView(
              imagePath: ImageConstant.imgSubtract,
              height: 16.adaptSize,
              width: 16.adaptSize,
              alignment: Alignment.topLeft,
              margin: EdgeInsets.only(left: 131.h, top: 21.v)),
          Align(
              alignment: Alignment.bottomLeft,
              child: Container(
                  width: 133.h,
                  margin: EdgeInsets.only(left: 16.h, bottom: 74.v),
                  child: Text("Make our home\nbecome green.",
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style:
                          CustomTextStyles.titleMediumRobotoLightgreenA70001))),
          CustomImageView(
              imagePath: ImageConstant.imgScreenshot20231013,
              height: 167.v,
              width: 145.h,
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(bottom: 8.v)),
          Align(
              alignment: Alignment.bottomCenter,
              child: SizedBox(
                  height: 208.v,
                  width: 358.h,
                  child: Stack(alignment: Alignment.topLeft, children: [
                    CustomImageView(
                        imagePath: ImageConstant.imgImage1,
                        height: 208.v,
                        width: 358.h,
                        alignment: Alignment.center),
                    Align(
                        alignment: Alignment.topLeft,
                        child: Padding(
                            padding: EdgeInsets.only(left: 16.h, top: 54.v),
                            child: Text("Hello Jack,",
                                style: CustomTextStyles
                                    .titleMediumRobotoBlack90019)))
                  ])))
        ]));
  }

  /// Section Widget
  Widget _buildImageScreen(BuildContext context) {
    return Align(
        alignment: Alignment.center,
        child: SizedBox(
            height: 47.v,
            width: 325.h,
            child: Stack(alignment: Alignment.topRight, children: [
              CustomImageView(
                  imagePath: ImageConstant.imgRectangle1,
                  height: 47.v,
                  width: 325.h,
                  radius: BorderRadius.circular(14.h),
                  alignment: Alignment.center),
              Align(
                  alignment: Alignment.topRight,
                  child: Container(
                      height: 36.v,
                      width: 31.h,
                      margin: EdgeInsets.only(top: 3.v, right: 12.h),
                      child: Stack(alignment: Alignment.topCenter, children: [
                        Align(
                            alignment: Alignment.bottomRight,
                            child: Container(
                                height: 22.adaptSize,
                                width: 22.adaptSize,
                                decoration: BoxDecoration(
                                    color: appTheme.blueGray100,
                                    borderRadius:
                                        BorderRadius.circular(11.h)))),
                        Align(
                            alignment: Alignment.topCenter,
                            child: Text("798m",
                                style: theme.textTheme.labelLarge)),
                        CustomImageView(
                            imagePath: ImageConstant.imgImage2,
                            height: 21.v,
                            width: 18.h,
                            alignment: Alignment.bottomRight,
                            margin: EdgeInsets.only(right: 2.h, bottom: 1.v))
                      ])))
            ])));
  }

  /// Section Widget
  Widget _buildCustomerMainPage(BuildContext context) {
    return SizedBox(
        height: 108.v,
        child: ListView.separated(
            padding: EdgeInsets.symmetric(horizontal: 8.h),
            scrollDirection: Axis.horizontal,
            separatorBuilder: (context, index) {
              return SizedBox(width: 19.h);
            },
            itemCount: 3,
            itemBuilder: (context, index) {
              return CustomermainpageItemWidget();
            }));
  }

  /// Navigates to the moreScreen when the action is triggered.
  onTapImgCircleImage(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.moreScreen);
  }

  /// Navigates to the pickupDetailsScreen when the action is triggered.
  onTapScheduleAPickup(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.pickupDetailsScreen);
  }
}
