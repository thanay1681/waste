import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:anabathula_s_application3/widgets/custom_outlined_button.dart';
import 'package:flutter/material.dart';

class CustomerLoginScreen extends StatelessWidget {
  const CustomerLoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: 375.h,
                child: Column(children: [
                  SizedBox(height: 84.v),
                  Expanded(
                      child: SingleChildScrollView(
                          child: Padding(
                              padding: EdgeInsets.only(
                                  left: 22.h, right: 22.h, bottom: 187.v),
                              child: Column(children: [
                                Container(
                                    margin:
                                        EdgeInsets.symmetric(horizontal: 26.h),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 50.h, vertical: 5.v),
                                    decoration: AppDecoration.fillGreen
                                        .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder20),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          SizedBox(height: 14.v),
                                          SizedBox(
                                              width: 174.h,
                                              child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text: "EcoHarvest\n",
                                                        style: CustomTextStyles
                                                            .headlineLargeRobotoBlack900),
                                                    TextSpan(
                                                        text:
                                                            "Trash to Treasure",
                                                        style: CustomTextStyles
                                                            .titleLargeRoboto)
                                                  ]),
                                                  textAlign: TextAlign.center))
                                        ])),
                                SizedBox(height: 317.v),
                                CustomElevatedButton(
                                    text: "Login",
                                    onPressed: () {
                                      onTapLogin(context);
                                    }),
                                SizedBox(height: 15.v),
                                CustomOutlinedButton(
                                    text: "Register",
                                    onPressed: () {
                                      onTapRegister(context);
                                    })
                              ]))))
                ]))));
  }

  /// Navigates to the loginOneScreen when the action is triggered.
  onTapLogin(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.loginOneScreen);
  }

  /// Navigates to the registerScreen when the action is triggered.
  onTapRegister(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.registerScreen);
  }
}
