import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:flutter/material.dart';

class ProfilePicScreen extends StatelessWidget {
  const ProfilePicScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        backgroundColor: theme.colorScheme.errorContainer,
        body: SizedBox(
          width: 300.h,
          child: CustomImageView(
            imagePath: ImageConstant.imgImage19,
            height: 300.adaptSize,
            width: 300.adaptSize,
            radius: BorderRadius.circular(
              150.h,
            ),
          ),
        ),
      ),
    );
  }
}
