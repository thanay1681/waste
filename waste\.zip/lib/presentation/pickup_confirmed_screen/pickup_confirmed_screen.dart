import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class PickupConfirmedScreen extends StatelessWidget {
  const PickupConfirmedScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.greenA100,
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.only(left: 42.h, top: 163.v, right: 42.h),
                child: Column(children: [
                  Text("Pickup Confirmed!!!",
                      style: theme.textTheme.titleLarge),
                  SizedBox(height: 38.v),
                  CustomImageView(
                      imagePath: ImageConstant.imgUnsplashOij61cg6s6s,
                      height: 134.adaptSize,
                      width: 134.adaptSize,
                      radius: BorderRadius.circular(67.h)),
                  SizedBox(height: 67.v),
                  SizedBox(
                      width: 274.h,
                      child: Text(
                          "The details will be sent your mobile number\nkinkly check for updates",
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: theme.textTheme.titleLarge)),
                  SizedBox(height: 19.v),
                  CustomElevatedButton(
                      height: 38.v,
                      text: "Back to Home",
                      margin: EdgeInsets.only(left: 40.h, right: 41.h),
                      buttonStyle: CustomButtonStyles.fillGreen,
                      buttonTextStyle: theme.textTheme.titleLarge!,
                      onPressed: () {
                        onTapBackToHome(context);
                      }),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Navigates to the customerMainPageContainerScreen when the action is triggered.
  onTapBackToHome(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.customerMainPageContainerScreen);
  }
}
