import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/app_bar/appbar_leading_iconbutton.dart';
import 'package:anabathula_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:anabathula_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class RegisterScreen extends StatelessWidget {
  RegisterScreen({Key? key}) : super(key: key);

  TextEditingController welcomeBackGladController = TextEditingController();

  TextEditingController userNameController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: Form(
                key: _formKey,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 30.v),
                    child: Padding(
                        padding: EdgeInsets.only(
                            left: 22.h, right: 22.h, bottom: 5.v),
                        child: Column(children: [
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Text("Register",
                                  style: theme.textTheme.headlineLarge)),
                          SizedBox(height: 93.v),
                          _buildWelcomeBackGlad(context),
                          SizedBox(height: 15.v),
                          _buildUserName(context),
                          SizedBox(height: 15.v),
                          _buildEmail(context),
                          SizedBox(height: 15.v),
                          _buildPassword(context),
                          SizedBox(height: 20.v),
                          _buildConfirmPassword(context),
                          SizedBox(height: 31.v),
                          _buildLoginWith(context),
                          SizedBox(height: 21.v),
                          _buildFacebookIc(context)
                        ]))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 375.h,
        leading: AppbarLeadingIconbutton(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.fromLTRB(36.h, 7.v, 298.h, 7.v),
            onTap: () {
              onTapArrowLeft(context);
            }));
  }

  /// Section Widget
  Widget _buildWelcomeBackGlad(BuildContext context) {
    return CustomTextFormField(
        controller: welcomeBackGladController, hintText: "Username");
  }

  /// Section Widget
  Widget _buildUserName(BuildContext context) {
    return CustomTextFormField(
        controller: userNameController,
        hintText: "Email",
        textInputType: TextInputType.emailAddress);
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return CustomTextFormField(
        controller: emailController,
        hintText: "Password",
        textInputType: TextInputType.visiblePassword,
        obscureText: true);
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return CustomTextFormField(
        controller: passwordController,
        hintText: "Confirm password",
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.visiblePassword,
        obscureText: true);
  }

  /// Section Widget
  Widget _buildConfirmPassword(BuildContext context) {
    return CustomElevatedButton(
        text: "Agree and Register",
        onPressed: () {
          onTapConfirmPassword(context);
        });
  }

  /// Section Widget
  Widget _buildLoginWith(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Padding(
          padding: EdgeInsets.symmetric(vertical: 8.v),
          child:
              SizedBox(width: 111.h, child: Divider(color: appTheme.indigo50))),
      Text("Or Login with", style: CustomTextStyles.titleSmallGray600),
      Padding(
          padding: EdgeInsets.symmetric(vertical: 8.v),
          child:
              SizedBox(width: 110.h, child: Divider(color: appTheme.indigo50)))
    ]);
  }

  /// Section Widget
  Widget _buildFacebookIc(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Container(
          height: 56.v,
          width: 105.h,
          padding: EdgeInsets.symmetric(horizontal: 38.h, vertical: 14.v),
          decoration: AppDecoration.outlineGray
              .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
          child: CustomImageView(
              imagePath: ImageConstant.imgFacebookIc,
              height: 26.adaptSize,
              width: 26.adaptSize,
              alignment: Alignment.center)),
      Container(
          height: 56.v,
          width: 105.h,
          padding: EdgeInsets.symmetric(horizontal: 38.h, vertical: 14.v),
          decoration: AppDecoration.outlineGray
              .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
          child: CustomImageView(
              imagePath: ImageConstant.imgGoogleIc,
              height: 26.adaptSize,
              width: 26.adaptSize,
              alignment: Alignment.center)),
      Container(
          height: 56.v,
          width: 105.h,
          padding: EdgeInsets.symmetric(horizontal: 38.h, vertical: 14.v),
          decoration: AppDecoration.outlineGray
              .copyWith(borderRadius: BorderRadiusStyle.roundedBorder8),
          child: CustomImageView(
              imagePath: ImageConstant.imgCibApple,
              height: 26.adaptSize,
              width: 26.adaptSize,
              alignment: Alignment.center))
    ]);
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }

  /// Navigates to the otpVerificationtwoScreen when the action is triggered.
  onTapConfirmPassword(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.otpVerificationtwoScreen);
  }
}
