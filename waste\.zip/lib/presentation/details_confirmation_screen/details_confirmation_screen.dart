import 'package:anabathula_s_application3/core/app_export.dart';
import 'package:anabathula_s_application3/widgets/app_bar/appbar_leading_iconbutton_one.dart';
import 'package:anabathula_s_application3/widgets/app_bar/appbar_subtitle_one.dart';
import 'package:anabathula_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:anabathula_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class DetailsConfirmationScreen extends StatelessWidget {
  const DetailsConfirmationScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: theme.colorScheme.onErrorContainer.withOpacity(1),
            body: SizedBox(
                height: mediaQueryData.size.height,
                width: double.maxFinite,
                child: Stack(alignment: Alignment.topCenter, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding: EdgeInsets.symmetric(vertical: 9.v),
                          decoration: AppDecoration.fillGreenA,
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                _buildAppBar(context),
                                Spacer(),
                                CustomElevatedButton(
                                    height: 38.v,
                                    width: 193.h,
                                    text: "Confirm pickup",
                                    margin: EdgeInsets.only(left: 74.h),
                                    buttonStyle: CustomButtonStyles.fillGreen,
                                    buttonTextStyle:
                                        theme.textTheme.titleLarge!,
                                    onPressed: () {
                                      onTapConfirmPickup(context);
                                    }),
                                SizedBox(height: 44.v),
                                Align(
                                    alignment: Alignment.center,
                                    child: SizedBox(
                                        width: 206.h,
                                        child: Text(
                                            "Take the First step to \na  new world",
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.center,
                                            style: CustomTextStyles
                                                .titleLargeOnErrorContainer))),
                                SizedBox(height: 5.v),
                                CustomImageView(
                                    imagePath:
                                        ImageConstant.imgUnsplashAi4rjMw4i,
                                    height: 263.v,
                                    width: 283.h,
                                    radius: BorderRadius.circular(119.h),
                                    alignment: Alignment.centerRight,
                                    margin: EdgeInsets.only(right: 28.h)),
                                SizedBox(height: 1.v)
                              ]))),
                  CustomImageView(
                      imagePath: ImageConstant.imgFrame4256x360,
                      height: 256.v,
                      width: 360.h,
                      alignment: Alignment.topCenter,
                      margin: EdgeInsets.only(top: 74.v))
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        height: 52.v,
        leadingWidth: 52.h,
        leading: AppbarLeadingIconbuttonOne(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 11.h, bottom: 11.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarSubtitleOne(
            text: "Details Conformation", margin: EdgeInsets.only(top: 27.v)));
  }

  /// Navigates back to the previous screen.
  onTapArrowLeft(BuildContext context) {
    Navigator.pop(context);
  }

  /// Navigates to the pickupConfirmedScreen when the action is triggered.
  onTapConfirmPickup(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.pickupConfirmedScreen);
  }
}
